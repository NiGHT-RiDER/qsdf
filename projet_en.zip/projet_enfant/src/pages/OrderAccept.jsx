import React from 'react';

// Components 
import Header from '../components/Header';
import AcceptedOrderTable from '../components/AcceptedOrderTable';

// Firebase
import { db } from '../firebase';
import { collection, query, where, getDocs, doc, onSnapshot, getDoc } from "firebase/firestore";

const OrderAccept = () => {

    const [orders, setOrders] = React.useState([]);

    const getOrders = async () => {

        const q1 = query(collection(db, "Orders"));

        onSnapshot(q1, snap1 => {

            setOrders([]);

            snap1.forEach(async doc1 => {

                const q1 = query(collection(db, "Orders"), where("OrderID", "==", doc1.data().OrderID), where("Status", "==", "Start"))

                const querySnapshot = await getDocs(q1);

                querySnapshot.forEach(async doc2 => {

                    const reference = doc(db, "products", doc2.data().p_id);

                    const doc3 = await getDoc(reference);

                    if (doc3.exists) {

                        let date = doc2.data().OrderDate.toMillis();

                        let payload1 = doc2.data();
                        payload1.OrderDate = date;

                        let payload2 = doc1.data();

                        let payload3 = doc3.data();

                        let payload = {
                            ...payload1,
                            ...payload2,
                            ...payload3
                        }

                        setOrders(pre => [
                            ...pre,
                            payload
                        ])
                    }

                })


            })



        })



        // const q1 = query(collection(db, "Orders"), where("Payement", "==", true))

        // // onSnapshot(q1, snap1 => {

        // const querySnapshot = await getDocs(q1);
        // querySnapshot.forEach(data1 => {

        //     const q2 = query(collection(db, "OrdersDetails"), where("OrderID", "==", String(data1.data().OrderID)))

        //     onSnapshot(q2, (snap2) => {
        //         setOrders([])

        //         snap2.forEach(async data2 => {

        //             const reference = doc(db, "products", data2.data().p_id);

        //             const data3 = await getDoc(reference);

        //             if (data3.exists) {

        //                 let date = data1.data().OrderDate.toMillis();

        //                 let payload1 = data1.data();
        //                 payload1.OrderDate = date;

        //                 let payload2 = data2.data();

        //                 let payload3 = data3.data();

        //                 let payload = {
        //                     ...payload1,
        //                     ...payload2,
        //                     ...payload3
        //                 }

        //                 setOrders(pre => [
        //                     ...pre,
        //                     payload
        //                 ])
        //             }

        //         })


        //     });

        // })

        // })

    }

    React.useEffect(() => {
        getOrders();
    }, [])

    return (
        <div>
            <Header page="Accepted Orders" />
            <div style={{ margin: '100px 0px' }}>
                <div className='my-5'>
                    <h2 className='text-center'>Kitchen</h2>
                </div>
                <AcceptedOrderTable data={orders} />
            </div>
        </div>
    )
}

export default OrderAccept;
