import React from 'react';

// Loader
import { css } from "@emotion/react";
import HashLoader from "react-spinners/HashLoader";

// Import UseForm 
import { useForm } from 'react-hook-form';

// Components 
import Header from '../components/Header';
import CategoryTable from '../components/CategoryTable';

// Mui 
import { Button } from '@mui/material';
import IconButton from '@mui/material/IconButton';
import TextField from '@mui/material/TextField';
import FormHelperText from '@mui/material/FormHelperText';

// Mui Icon 
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';

// Firebase 
import { db, storage } from '../firebase';
import { collection, doc, setDoc, query, onSnapshot } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";

// React Modal 
import ReactModal from 'react-modal';

// Swal 
import swal from 'sweetalert';


const override = css`
  display: block;
  margin: 0 auto;
`;


const Category = () => {

    const { register, handleSubmit, formState: { errors }, reset } = useForm();

    const [showModal, setShowModal] = React.useState(false);
    const [categories, setCategories] = React.useState([]);
    const [loading, setLoading] = React.useState(false);
    let [color] = React.useState("#000");


    const handleOpenModal = () => {
        setShowModal(true);
    }

    const handleCloseModal = () => {
        setShowModal(false);
    }

    const onSubmit = async data => {

        setLoading(true);

        var allowedExtension = [
            "image/jpeg",
            "image/jpg",
            "image/png",
            "image/gif",
            "image/bmp",
          ];
          var isValidFile = false;
          for (var index in allowedExtension) {
            if (data.file[0].type === allowedExtension[index]) {
              isValidFile = true;
              break;
            }
          }

          
        if (!isValidFile) {
            alert("Allowed Extensions are : *." + allowedExtension.join(", *."));
            setLoading(false);
            return;
        }

        const key = doc(collection(db, "categories")).id;

          // Create a reference to 'mountains.jpg'
         const storageRef = ref(storage, key);

         uploadBytes(storageRef, data.file[0]).then(() => {
            getDownloadURL(storageRef).then(async (url) => {
              await setDoc(doc(db, "categories", key), {
                cat_id: key,
                cat_image: url,
                cat_name: data.category
              })
                .then(() => {
                  setLoading(false);
                  swal("Added", "Category Added!", "success").then(() => {
                    setShowModal(false);
                    reset();
                  });
                })
                .catch((err) => {
                  setLoading(false);
                  alert(err.message);
                });
            });
          });
        };
        // await setDoc(doc(db, "categories", key), {
        //     "cat_id": key,
        //     "cat_name": data.category,
        //     "cat_image": data.image
        // })
            // .then(() => {
            //     setLoading(false);

            //     swal("Added", "Category Added!", "success")
            //         .then(() => {
            //             setShowModal(false);
            //             reset();
            //         });
            // })
            // .catch(err => {
            //     setLoading(false);
            //     alert(err.message);
            // })

    // }

    const getCategories = async () => {

        const q = query(collection(db, "categories"));

        onSnapshot(q, (querySnapshot) => {
            setCategories([]);
            querySnapshot.forEach((doc) => {
                setCategories(pre => [
                    ...pre,
                    doc.data()
                ])
            });
        });

    }

    React.useEffect(() => {
        getCategories();
    }, [])

    return (
        <div>

            <div className={loading ? 'process-loading' : null} >
                <HashLoader
                    color={color}
                    loading={loading}
                    css={override}
                    size={70} />
            </div>

            <Header page="Category" />
            <div style={{ margin: '100px 0px' }}>
                <div className="container">
                    <Button
                        variant="contained"
                        startIcon={<AddRoundedIcon />}
                        size="large"
                        onClick={handleOpenModal}
                        color="success"
                    >Add new category</Button>
                </div>
                <div className='my-5'>
                    <h2 className='text-center'>Category</h2>
                </div>
                <CategoryTable data={categories} />
            </div>

            <ReactModal
                isOpen={showModal}
                style={{
                    content: {
                        width: "60%",
                        margin: '100px auto 0px auto'
                    }
                }}
            // contentLabel="Minimal Modal Example"
            >
                <div className='text-end'>
                    <IconButton aria-label="close" onClick={handleCloseModal}>
                        <CloseRoundedIcon />
                    </IconButton>
                </div>
                <h1 className='text-center h4'>Add New Category</h1>

                <div className="row">

                    <div className="col-lg-8 col-md-8 col-sm-10 col-12 mx-auto">

                        <form onSubmit={handleSubmit(onSubmit)} className='mt-5'>

                            <div className='mb-3'>
                                <TextField
                                    label="Category Name"
                                    fullWidth
                                    variant="outlined"
                                    size='small'
                                    {...register("category", {
                                        required: {
                                            value: true,
                                            message: "Category Name is required"
                                        }
                                    })}
                                    error={errors.category}
                                />
                                {errors.category && <FormHelperText error>{errors.category.message}</FormHelperText>}

                            </div>

                            <div className="mb-3">
                                <input
                                type="file"
                                className={
                                    errors.file ? "form-control is-invalid" : "form-control"
                                }
                                {...register("file", {
                                    required: {
                                    value: true,
                                    message: "Image is required",
                                    },
                                })}
                                />
                                {errors.file && (
                                <FormHelperText error>{errors.file.message}</FormHelperText>
                                )}
                            </div>

                            <Button
                                type='submit'
                                variant='contained'
                                fullWidth
                                size='large'>Add</Button>

                        </form>

                    </div>

                </div>

            </ReactModal>

        </div>
    )
}

export default Category;
