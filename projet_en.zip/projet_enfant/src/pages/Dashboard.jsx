import React from 'react'
import Header from "../components/Header";
import HashLoader from "react-spinners/HashLoader";
import { css } from "@emotion/react";

import LeaderboardIcon from '@mui/icons-material/Leaderboard';
import ShowChartIcon from '@mui/icons-material/ShowChart';


// Firebase 
import { db } from '../firebase';
import { collection, query, where, onSnapshot } from "firebase/firestore";

import DashboardTable from '../components/DashboardTable';


const override = css`
  display: block;
  margin: 0 auto;
`;

function Dashboard() {
  let [color] = React.useState("#000")
  const [loading, setLoading] = React.useState(false);

  const [orders, setOrders] = React.useState([]);

  const [products, setProducts] = React.useState([]);

  const getProductsRecords = async () => {

    const q = query(collection(db, "products"));

    onSnapshot(q, (querySnapshot) => {
      setProducts([]);
        querySnapshot.forEach((doc) => {
          setProducts(pre => [
                ...pre,
                doc.data()
            ])
        });
    });

  }


  const getOrdersRecords = async () => {

    const q = query(collection(db, "Orders"), where("Status", "==", "paid"));

    onSnapshot(q, (querySnapshot) => {
        setOrders([]);
        querySnapshot.forEach((doc) => {
            setOrders(pre => [
                ...pre,
                doc.data()
            ])
        });
    });

  }

  React.useEffect(async () => {
    getProductsRecords()
    getOrdersRecords();
  }, [])



  return (
    <div>
      <div className={loading ? "process-loading" : null}>
        <HashLoader color={color} loading={loading} css={override} size={70} />
      </div>
      <Header page="Dashboard" />

      <div style={{ margin: '100px 0px' }}>
        
        <main>
          <div className="insights">

            <div className="profit">
              <ShowChartIcon className='text-primary'/>
              <div className="middle">
                <div className="left">
                  <h3>Total Profit</h3>
                  <h1>€35000</h1>
                </div>
    
                <select className='text-muted' name="most_time" id="most_time">
                  <option value="last24">last 24h</option>
                  <option value="week">week</option>
                  <option value="month">month</option>
                  <option value="year">year</option>
                </select>
              </div>
              
            </div>

            <div className="sales-prod">
              <LeaderboardIcon className='text-success'/>
              <div className="middle">
                <div className="left">
                  <h3>Most sold</h3>
                  <h1>King burger</h1>
                </div>

                <select className='text-muted' name="most_time" id="most_time">
                  <option value="last24">last 24h</option>
                  <option value="week">week</option>
                  <option value="month">month</option>
                  <option value="year">year</option>
                </select>
              </div>
            </div>

            <div className="sales-cat">
              <LeaderboardIcon className='text-danger'/>
              <div className="middle">
                <div className="left">
                  <h3>Least sold</h3>
                  <h1>COCA-COLA</h1>
                </div>
                <select className='text-muted' name="most_time" id="most_time">
                  <option value="last24">last 24h</option>
                  <option value="week">week</option>
                  <option value="month">month</option>
                  <option value="year">year</option>
                </select>
              </div>


            </div>
          </div>

          <DashboardTable orders={orders} products={products}/>

        </main>

      </div>
  </div>
  )
}

export default Dashboard