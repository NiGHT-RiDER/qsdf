import React from "react";

// Loader
import { css } from "@emotion/react";
import HashLoader from "react-spinners/HashLoader";

// Import UseForm
import { useForm } from "react-hook-form";

// Components
import Header from "../components/Header";
import UserTable from "../components/UsersTable";

// Mui
import { Button } from "@mui/material";
import IconButton from "@mui/material/IconButton";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import InputLabel from "@mui/material/InputLabel";
import FormHelperText from "@mui/material/FormHelperText";

// Mui Icon
import AddRoundedIcon from "@mui/icons-material/AddRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";

// Firebase
import { auth, db } from "../firebase";
import { collection, doc, setDoc, onSnapshot, query } from "firebase/firestore";

// React Modal
import ReactModal from "react-modal";

// Swal
import swal from "sweetalert";
import { createUserWithEmailAndPassword } from "firebase/auth";

const override = css`
  display: block;
  margin: 0 auto;
`;

const AddUsers = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm();
  const [showModal, setShowModal] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [users, setUsers] = React.useState([]);

  let [color] = React.useState("#000");

  const handleOpenModal = () => {
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  const onSubmit = (data) => {
    setLoading(true);

    createUserWithEmailAndPassword(auth, data.email, data.password)
      .then(async (userCredential) => {
        // Signed in

        await setDoc(doc(db, "users", userCredential.user.uid), {
          username: data.username,
          email: data.email,
          uid: userCredential.user.uid,
          department: data.department,
        }).then(() => {
          setLoading(false);
          swal("Added", "User Added!", "success").then(() => {
            setShowModal(false);
            reset();
          });
        });

        // ...
      })
      .catch((error) => {
        setLoading(false);
        const errorMessage = error.message;
        swal("Error!", errorMessage + "!", "error");
        // ..
      });
  };

  const getUsers = async () => {
    const q = query(collection(db, "users"));

    onSnapshot(q, (querySnapshot) => {
      setUsers([]);
      querySnapshot.forEach((doc) => {
        setUsers((pre) => [...pre, doc.data()]);
      });
    });
  };

  React.useEffect(() => {
    getUsers();
  }, []);

  return (
    <div>
      <div className={loading ? "process-loading" : null}>
        <HashLoader color={color} loading={loading} css={override} size={70} />
      </div>

      <Header page="Users" />
      <div style={{ margin: "100px 0px" }}>
        <div className="container">
          <Button
            variant="contained"
            startIcon={<AddRoundedIcon />}
            size="large"
            color="success"
            onClick={handleOpenModal}
          >
            Add User
          </Button>
        </div>
        <div className="my-5">
          <h2 className="text-center">Users</h2>
        </div>
        {/* <UserTable cate={categories} data={products} /> */}
        <UserTable data={users} />
      </div>
      <ReactModal
        isOpen={showModal}
        style={{
          content: {
            width: "60%",
            margin: "100px auto 0px auto",
          },
        }}
        contentLabel="Minimal Modal Example"
      >
        <div className="text-end">
          <IconButton aria-label="close" onClick={handleCloseModal}>
            <CloseRoundedIcon />
          </IconButton>
        </div>
        <h1 className="text-center h4">Add New User</h1>

        <div className="row">
          <div className="col-lg-8 col-md-8 col-sm-10 col-12 mx-auto">
            <form onSubmit={handleSubmit(onSubmit)} className="mt-5">
              <div className="mb-3">
                <TextField
                  label="Full Name"
                  fullWidth
                  variant="outlined"
                  size="small"
                  {...register("username", {
                    required: {
                      value: true,
                      message: "Full Name is required",
                    },
                  })}
                  error={errors.username}
                />
                {errors.username && (
                  <FormHelperText error>
                    {errors.username.message}
                  </FormHelperText>
                )}
              </div>

              <div className="mb-3">
                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">
                    Department
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    label="Department"
                    {...register("department", {
                      required: {
                        value: true,
                        message: "Select Department",
                      },
                    })}
                    error={errors.department}
                  >
                    <MenuItem value="cashier">Cashier</MenuItem>
                    <MenuItem value="kitchen">Kitchen</MenuItem>
                    <MenuItem value="admin">Admin</MenuItem>
                    <MenuItem value="x">X</MenuItem>
                  </Select>
                  {errors.department && (
                    <FormHelperText error>
                      {errors.department.message}
                    </FormHelperText>
                  )}
                </FormControl>
              </div>

              <div className="mb-3">
                <TextField
                  label="Email"
                  fullWidth
                  variant="outlined"
                  size="small"
                  {...register("email", {
                    required: {
                      value: true,
                      message: "Email Address is required",
                    },
                    pattern: {
                      value: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
                      message: "Email address is invalid",
                    },
                  })}
                  error={errors.email}
                />
                {errors.email && (
                  <FormHelperText error>{errors.email.message}</FormHelperText>
                )}
              </div>

              <div className="mb-3">
                <TextField
                  label="Password"
                  fullWidth
                  variant="outlined"
                  type="password"
                  size="small"
                  {...register("password", {
                    required: {
                      value: true,
                      message: "Password is required",
                    },
                  })}
                  error={errors.password}
                />
                {errors.password && (
                  <FormHelperText error>
                    {errors.password.message}
                  </FormHelperText>
                )}
              </div>

              <Button type="submit" variant="contained" fullWidth size="large">
                Add
              </Button>
            </form>
          </div>
        </div>
      </ReactModal>
    </div>
  );
};

export default AddUsers;
