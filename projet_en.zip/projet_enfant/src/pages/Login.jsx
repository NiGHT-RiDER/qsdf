import React from 'react';

// UseForm 
import { useForm } from "react-hook-form";

// Mui 
import TextField from '@mui/material/TextField';
import { Button } from '@mui/material';
import FormHelperText from '@mui/material/FormHelperText';

// Swal 
import swal from 'sweetalert';

// Firebase 
import { auth } from '../firebase';
import { signInWithEmailAndPassword } from 'firebase/auth'

const Login = () => {

    const { register, handleSubmit, formState: { errors } } = useForm();
    const [disBtn, setDisBtn] = React.useState(false);

    const onSubmit = data => {
        setDisBtn(true);
        signInWithEmailAndPassword(auth, data.email, data.password)
            .then(() => {
                console.log("user found");
            })
            .catch(err => {
                setDisBtn(false);
                const errorMessage = err.message;
                swal("Error!", errorMessage + "!", "error");
            })
    }

    return (
        <div style={{ margin: '100px 0px' }}>
            <div className="container">
                <div className="row">
                    <div className="col-lg-6 col-md-8 col-sm-10 col-12 mx-auto">
                        <h1 className='text-center'>LOGIN</h1>

                        <form onSubmit={handleSubmit(onSubmit)} className='mt-5'>

                            <div className='mb-3'>
                                <TextField
                                    fullWidth
                                    label="Email"
                                    variant="outlined"
                                    {...register("email", {
                                        required: {
                                            value: true,
                                            message: "Email Address is required"
                                        },
                                        pattern: {
                                            value: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
                                            message: "Email address is invalid"
                                        }
                                    })}
                                    error={errors.email}
                                />
                                {errors.email && <FormHelperText error>{errors.email.message}</FormHelperText>}

                            </div>

                            <div className='mb-3'>
                                <TextField
                                    fullWidth
                                    label="Password"
                                    variant="outlined"
                                    type={'password'}
                                    {...register('password', {
                                        required: {
                                            value: true,
                                            message: "Password is required"
                                        }
                                    })}
                                    error={errors.password}
                                />
                                {errors.password && <FormHelperText error>{errors.password.message}</FormHelperText>}
                            </div>

                            {disBtn ? <Button variant='contained' fullWidth size='large' disabled>Login</Button> :
                                <Button type='submit' variant='contained' size='large' className="fw-bold" fullWidth>Login</Button>}


                        </form>

                    </div>
                </div>
            </div>
        </div>
    )
}

export default Login;
