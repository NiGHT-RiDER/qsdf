import React from 'react';

// Loader
import { css } from "@emotion/react";
import HashLoader from "react-spinners/HashLoader";

// Import UseForm 
import { useForm } from 'react-hook-form';

// Components 
import Header from '../components/Header';
import IngredientsTable from '../components/IngredientsTable';

// Mui 
import { Button } from '@mui/material';
import IconButton from '@mui/material/IconButton';
import TextField from '@mui/material/TextField';
import FormHelperText from '@mui/material/FormHelperText';

// Mui Icon 
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';

// Firebase 
import { db } from '../firebase';
import { collection, doc, setDoc, query, onSnapshot } from "firebase/firestore";

// React Modal 
import ReactModal from 'react-modal';

// Swal 
import swal from 'sweetalert';

const override = css`
  display: block;
  margin: 0 auto;
`;

function Ingredients() {

    const { register, handleSubmit, formState: { errors }, reset } = useForm();

    const [showModal, setShowModal] = React.useState(false);
    const [ingredients, setIngredients] = React.useState([]);
    const [loading, setLoading] = React.useState(false);
    let [color] = React.useState("#000");


    const handleOpenModal = () => {
        setShowModal(true);
    }

    const handleCloseModal = () => {
        setShowModal(false);
    }

    const onSubmit = async data => {

        setLoading(true);
        const key = doc(collection(db, "ingredients")).id;

        await setDoc(doc(db, "ingredients", key), {
            "ingredient_id": key,
            "ingredient_name": data.ingredient
        })
            .then(() => {
                setLoading(false);

                swal("Added", "Ingredient Added!", "success")
                    .then(() => {
                        setShowModal(false);
                        reset();
                    });
            })
            .catch(err => {
                setLoading(false);
                alert(err.message);
            })

    }

    const getIngredients = async () => {

        const q = query(collection(db, "ingredients"));

        onSnapshot(q, (querySnapshot) => {
            setIngredients([]);
            querySnapshot.forEach((doc) => {
                setIngredients(pre => [
                    ...pre,
                    doc.data()
                ])
            });
        });

    }

    React.useEffect(() => {
        getIngredients();
    }, [])


  return (
        <div>
            <div className={loading ? 'process-loading' : null} >
                <HashLoader
                    color={color}
                    loading={loading}
                    css={override}
                    size={70} />
            </div>

            <Header page="Ingredient" />
            <div style={{ margin: '100px 0px' }}>
                <div className="container">
                    <Button
                        variant="contained"
                        startIcon={<AddRoundedIcon />}
                        size="large"
                        onClick={handleOpenModal}
                        color="success"
                    >Add new Ingredient</Button>
                </div>
                <div className='my-5'>
                    <h2 className='text-center'>Ingredient</h2>
                </div>
                <IngredientsTable data={ingredients} />
            </div>
            <ReactModal
                isOpen={showModal}
                style={{
                    content: {
                        width: "60%",
                        margin: '100px auto 0px auto'
                    }
                }}
            // contentLabel="Minimal Modal Example"
            >
                              <div className='text-end'>
                    <IconButton aria-label="close" onClick={handleCloseModal}>
                        <CloseRoundedIcon />
                    </IconButton>
                </div>
                <h1 className='text-center h4'>Add New Ingredient</h1>
            
                <div className="row">

                    <div className="col-lg-8 col-md-8 col-sm-10 col-12 mx-auto">

                        <form onSubmit={handleSubmit(onSubmit)} className='mt-5'>

                            <div className='mb-3'>
                                <TextField
                                    label="Ingredient Name"
                                    fullWidth
                                    variant="outlined"
                                    size='small'
                                    {...register("ingredient", {
                                        required: {
                                            value: true,
                                            message: "Ingredient Name is required"
                                        }
                                    })}
                                    error={errors.ingredient}
                                />
                                {errors.ingredient && <FormHelperText error>{errors.ingredient.message}</FormHelperText>}

                            </div>

                            <Button
                                type='submit'
                                variant='contained'
                                fullWidth
                                size='large'>Add</Button>

                        </form>

                    </div>

                </div>

            </ReactModal>



            

        </div>
  )
}

export default Ingredients