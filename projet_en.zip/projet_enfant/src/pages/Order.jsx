import React from 'react';

// Loader
import { css } from "@emotion/react";
import HashLoader from "react-spinners/HashLoader";

// Components 
import Header from '../components/Header';
import OrderTable from '../components/OrderTable';


// Firebase 
import { db } from '../firebase';
import { collection, query, onSnapshot } from "firebase/firestore";

const override = css`
  display: block;
  margin: 0 auto;
`;

const Order = () => {

    const [loading] = React.useState(false);

    let [color] = React.useState("#000");

    const [orders, setOrders] = React.useState([]);

    const getRecords = async () => {

        const q = query(collection(db, "Orders"));

        onSnapshot(q, (querySnapshot) => {
            setOrders([]);
            querySnapshot.forEach((doc) => {
                setOrders(pre => [
                    ...pre,
                    doc.data()
                ])
            });
        });

    }

    React.useEffect(() => {
        getRecords();
    }, [])

    return (
        <div>

            <div className={loading ? 'process-loading' : null} >
                <HashLoader
                    color={color}
                    loading={loading}
                    css={override}
                    size={70} />
            </div>

            <Header page="Orders" />
            <div style={{ margin: '100px 0px' }}>
                <div className='my-5'>
                    <h2 className='text-center'>Orders</h2>
                </div>
                <OrderTable data={orders} />
            </div>

        </div>
    )
}

export default Order
