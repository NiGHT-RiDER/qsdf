import React from 'react'
import Header from '../components/Header'
import HashLoader from "react-spinners/HashLoader";
import { css } from "@emotion/react";
import PieChart from '../components/charts/PieChart';
import BarChart from '../components/charts/BarChart';

const override = css`
  display: block;
  margin: 0 auto;
`;

function Charts() {

    let [color] = React.useState("#000")
    const [loading, setLoading] = React.useState(false);

    let dt = [{x: "King burger", y:18, text: '35%'},{x: "Pizza MARG", y:18, text: '15%'},{x: "Cheese burger", y:18, text: '25%'},{x: "bbq chicken", y:18, text: '25%'}]

  return (
    <div>
        <div className={loading ? "process-loading" : null}>
            <HashLoader color={color} loading={loading} css={override} size={70} />
        </div>
        <Header page="Charts" />

        <div className='charts' style={{ margin: '100px 0px' }}>

            <PieChart id="chart-pie" data={dt} legendVisiblity height="full"/>

            <BarChart id="barchart"/>

        </div>
    </div>
  )
}

export default Charts