import React from 'react'


const DashboardTable = ({ orders, products }) => {



    return (
        <div className="recent-orders">

              <h2>Recent Orders</h2>
              <table>
                <thead>
                  <tr>
                    <th>OrderID</th>
                    <th>Product names</th>
                    <th>Total Paid</th>
                  </tr>
                </thead>
                <tbody>

                  {orders.filter((item, idx) => idx < 10).map((v,k) => {

                    let prodlist = [];
                    let toString = [];
                    

                    v.ProductID.forEach(e => {
                      products.find( s => {if(s.p_id == e){
                        prodlist.push(s.p_name);
                      }})
                    } )

                    let prodnames = prodlist.filter((value, index, self) => {return self.indexOf(value) === index})

                    for (let a of prodnames.filter((v, i, a) => a.indexOf(v) === i)){
                      let times = 0;
                      prodlist.forEach(element => {
                        if(element.localeCompare(a) == 0)
                          times++;
                      })
                      toString.push(`${a}(${times})`)
                    }

                    return <tr>
                    <td>{v.OrderID.slice(0,5)}***</td>
                    <td>{toString.join(`, `)}</td>
                    <td>€{v.Price}</td>
                    </tr>                              
                  })}

                </tbody>
              </table>
              <a href='#'>Show All</a>

            </div>
    )
}


export default DashboardTable;