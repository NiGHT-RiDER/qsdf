import React from 'react';
import { ChartComponent, SeriesCollectionDirective, SeriesDirective, Inject, Legend, Category, Tooltip, ColumnSeries, DataLabel } from '@syncfusion/ej2-react-charts';



const BarChart = ({ id, barPrimaryXAxis, barPrimaryYAxis, barCustomSeries }) => {

    let xAxis = {valueType: 'Category', interval: 1, majorGridLines: {width: 0} }
    let yAxis = {labelStyle: {color: 'transparent'}, title:"Total sold", lineStyle: {width: 0}, majorGridLines: {width: 0}, majorTickLines: {width: 0} }

    let data = [];

    let test = [{category:"Pizza", sold: 35},{category:"Pizza", sold: 21},{category:"Pizza", sold: 35} ]

    





    let dt = [
        {name: "Gold", type: "Column", xName: "x", yName: "y",marker: {dataLabel: {position: "Top", visible: true, font: {fontWeight: '600', color: '#ffffff'}}}, dataSource: [{x: "Pizza", y:46},{x: "Burgers", y:27}, {x: "Drinks", y:26}] },
        {name: "Silver", type: "Column", xName: "x", yName: "y",marker: {dataLabel: {position: "Top", visible: true, font: {fontWeight: '600', color: '#ffffff'}}}, dataSource: [{x: "Pizza", y:23},{x: "Burgers", y:27}, {x: "Drinks", y:26}] },
        {name: "Bronze", type: "Column", xName: "x", yName: "y",marker: {dataLabel: {position: "Top", visible: true, font: {fontWeight: '600', color: '#ffffff'}}}, dataSource: [{x: "Pizza", y:12},{x: "Burgers", y:27}, {x: "Drinks", y:26}] }
        ];



  return (
    <div className="Chart">
        <h3 className='text-muted fs-5'>Chart</h3>
        <h1>Bar</h1>
      <div className="mt-5 w-full">
        <ChartComponent
          id={id}
          primaryXAxis={xAxis}
          primaryYAxis={yAxis}
          chartArea={{ border: { width: 0 } }}
          tooltip={{ enable: true }}
          legendSettings={{ background: 'white' }}
        >
          <Inject services={[ColumnSeries, Legend, Tooltip, Category, DataLabel]} />
          <SeriesCollectionDirective>
            {dt.map((item, index) => <SeriesDirective key={index} {...item} />)}
          </SeriesCollectionDirective>
        </ChartComponent>
      </div>
    </div>
  );
};

export default BarChart;
