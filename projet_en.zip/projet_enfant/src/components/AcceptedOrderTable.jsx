import React from 'react';

// Loader
import { css } from "@emotion/react";
import HashLoader from "react-spinners/HashLoader";

// Mui 
import { Button } from '@mui/material';

// Moment 
import moment from 'moment';

// Firebase
import { db } from '../firebase';
import { doc, updateDoc } from "firebase/firestore";


// Sweet Alert 
import swal from 'sweetalert';

const override = css`
  display: block;
  margin: 0 auto;
`;


const AcceptedOrderTable = ({ data }) => {

    const [loading, setLoading] = React.useState(false);

    let [color] = React.useState("#000");

    // console.log(data);
    // console.log(details);

    const updateStatus = id => {

        swal({
            title: "Are you sure?",
            text: "Is the order done?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
            .then(async (willDelete) => {
                if (willDelete) {

                    setLoading(true);

                    const reference = doc(db, "OrdersDetails", id);

                    await updateDoc(reference, {
                        Status: true
                    })
                        .then(() => {
                            setLoading(false);
                            swal("Updated!", "The order is done", "success");

                        })
                        .catch((err) => {
                            alert(err.message);
                            setLoading(false);
                        })

                }
            });

    }

    return (
        <div className="container mt-5">

            <div className={loading ? 'process-loading' : null} >
                <HashLoader
                    color={color}
                    loading={loading}
                    css={override}
                    size={70} />
            </div>


            <div className="table-responsive" >
                <table className="table table-hover table-lg">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Product Name</th>
                            <th scope="col">Category</th>
                            <th scope="col">Total</th>
                            <th scope="col">Update</th>
                            <th scope="col">Print</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map((v, i) => (
                            <tr key={i}>
                                <td>{i + 1}</td>
                                <td>{v.p_name}</td>
                                <td>{v.c_id}</td>
                                <td>{v.p_name}</td>
                                <td>{moment(v.OrderDate).format('MMMM Do YYYY, h:mm:ss a')}</td>
                                <td>{v.Price}</td>
                                <td>
                                    {v.Status ? <Button variant="contained">
                                        Done
                                    </Button> : <Button variant="contained" onClick={() => updateStatus(v.id)}>
                                        Update
                                    </Button>}

                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div >

        </div>
    )
}

export default AcceptedOrderTable
