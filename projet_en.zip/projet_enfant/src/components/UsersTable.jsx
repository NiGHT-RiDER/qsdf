import React from "react";

// Loader
import { css } from "@emotion/react";
import HashLoader from "react-spinners/HashLoader";

// Import UseForm
import { useForm } from "react-hook-form";

// Mui
import { Button } from "@mui/material";
import IconButton from "@mui/material/IconButton";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import InputLabel from "@mui/material/InputLabel";
import FormHelperText from "@mui/material/FormHelperText";

// Mui Icon
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";

// Firebase
import { sendPasswordResetEmail } from "firebase/auth";
import { doc, updateDoc } from "firebase/firestore";
import { auth, db } from "../firebase";

// Sweet Alert
import swal from "sweetalert";

// React Modal
import ReactModal from "react-modal";

const override = css`
  display: block;
  margin: 0 auto;
`;

const UserTable = ({ data }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm();

  const [showModal, setShowModal] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [departVal, setDepartVal] = React.useState("");
  const [index, setIndex] = React.useState();

  let [color] = React.useState("#000");

  const handleOpenModal = (id) => {
    setValue("username", data[id].username);
    setDepartVal(data[id].department);
    setIndex(id);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  const resetPassword = (id) => {
    console.log(data[id].email);
    swal({
      title: "Are you sure?",
      text: `You want to reset password for ${data[id].email}`,
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        sendPasswordResetEmail(auth, data[id].email)
          .then(() => {
            swal("A email has been sent to reset password", {
              icon: "success",
            });
          })
          .catch((error) => {
            swal(error.message, {
              icon: "error",
            });
          });
      }
    });
  };

  const onSubmit = async (value) => {
    setLoading(true);

    const ref = doc(db, "users", data[index].uid);

    await updateDoc(ref, {
      username: value.username,
      department: value.department,
    })
      .then(() => {
        setLoading(false);

        swal("Updated", "User Updated!", "success").then(() => {
          setShowModal(false);
        });
      })
      .catch((err) => {
        setLoading(false);
        swal("Error", err.message, "error");
      });
  };

  return (
    <div className="container mt-5">
      <div className={loading ? "process-loading" : null}>
        <HashLoader color={color} loading={loading} css={override} size={70} />
      </div>

      <div className="table-responsive">
        <table className="table table-hover table-lg">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Username</th>
              <th scope="col">Department</th>
              <th scope="col">Email</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {data.map((v, i) => (
              <tr key={i}>
                <th>{i + 1}</th>
                <td>{v.username}</td>
                <td>{v.department}</td>
                <td>{v.email}</td>
                <td>
                  <Button
                    variant="contained"
                    className="mx-1"
                    onClick={() => handleOpenModal(i)}
                    data-bs-toggle="modal"
                    data-bs-target="#staticBackdrop"
                  >
                    Edit
                  </Button>
                  <Button
                    variant="contained"
                    className="mx-1"
                    onClick={() => resetPassword(i)}
                    data-bs-toggle="modal"
                    data-bs-target="#staticBackdrop"
                  >
                    Reset Password
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <ReactModal
        isOpen={showModal}
        style={{
          content: {
            width: "60%",
            margin: "100px auto 0px auto",
          },
        }}
        contentLabel="Minimal Modal Example"
      >
        <div className="text-end">
          <IconButton aria-label="close" onClick={handleCloseModal}>
            <CloseRoundedIcon />
          </IconButton>
        </div>
        <h1 className="text-center h4">Update User</h1>

        <div className="row">
          <div className="col-lg-8 col-md-8 col-sm-10 col-12 mx-auto">
            <form onSubmit={handleSubmit(onSubmit)} className="mt-5">
              <div className="mb-3">
                <TextField
                  label="Full Name"
                  fullWidth
                  variant="outlined"
                  size="small"
                  {...register("username", {
                    required: {
                      value: true,
                      message: "Full Name is required",
                    },
                  })}
                  error={errors.username}
                />
                {errors.username && (
                  <FormHelperText error>
                    {errors.username.message}
                  </FormHelperText>
                )}
              </div>

              <div className="mb-3">
                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">
                    Department
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    defaultValue={departVal}
                    label="Department"
                    {...register("department", {
                      required: {
                        value: true,
                        message: "Select Department",
                      },
                    })}
                    error={errors.department}
                  >
                    <MenuItem value="cashier">Cashier</MenuItem>
                    <MenuItem value="kitchen">Kitchen</MenuItem>
                    <MenuItem value="admin">Admin</MenuItem>
                    <MenuItem value="x">X</MenuItem>
                  </Select>
                  {errors.department && (
                    <FormHelperText error>
                      {errors.department.message}
                    </FormHelperText>
                  )}
                </FormControl>
              </div>

              <Button type="submit" variant="contained" fullWidth size="large">
                Update
              </Button>
            </form>
          </div>
        </div>
      </ReactModal>
    </div>
  );
};

export default UserTable;
