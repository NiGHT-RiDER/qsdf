import React from 'react'


function Footer() {
  return (
    <footer>
        <p className='text-center'>Copyright &copy; fs-checkout.com</p>
    </footer>
  )
}

export default Footer