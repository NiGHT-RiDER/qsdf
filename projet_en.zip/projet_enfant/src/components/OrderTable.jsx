import React from 'react';

// Loader
import { css } from "@emotion/react";
import HashLoader from "react-spinners/HashLoader";

// Mui 
import { Button } from '@mui/material';

// Firebase 
import { doc, updateDoc, deleteDoc } from "firebase/firestore";
import { db } from '../firebase';

// Sweet Alert 
import swal from 'sweetalert';

const override = css`
  display: block;
  margin: 0 auto;
`;

const OrderTable = ({ data }) => {

    const [loading, setLoading] = React.useState(false);

    let [color] = React.useState("#000");


    const updateOrder = (i) => {

        swal({
            title: "Are you sure?",
            text: "Is it paid?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
            .then(async (willDelete) => {
                if (willDelete) {

                    setLoading(true);

                    const reference = doc(db, "Orders", data[i].OrderID);

                    await updateDoc(reference, {
                        Status: "start"
                    })
                        .then(() => {
                            setLoading(false);
                            swal("Updated!", "Payment Status Updated!!", "success");

                        })
                        .catch((err) => {
                            alert(err.message);
                            setLoading(false);
                        })

                }
            });

    }
    return (
        <div className="container mt-5">

            <div className={loading ? 'process-loading' : null} >
                <HashLoader
                    color={color}
                    loading={loading}
                    css={override}
                    size={70} />
            </div>

            <div className="table-responsive" >
                <table className="table table-hover table-lg">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Order Table</th>
                            <th scope='col'>Price</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map((v, i) => {
                            if(v.Status == "not paid"){

                            
                            return <tr key={i}>
                                <td>{v.OrderNumber}</td>
                                <td>{v.OrderTable}</td>
                                <td>€ {v.Price}</td>
                                <td>{v.Status}</td>
                                <td>
                                    <div>
                                        <Button
                                            variant='contained'
                                            className='mx-1'
                                            onClick={() => updateOrder(i)}>
                                            Edit
                                        </Button>
                                      
                                    </div>



                                </td>
                            </tr>
                            } else {

                            }
                        })}
                    </tbody>
                </table>
            </div >

        </div >
    )
}


export default OrderTable;
