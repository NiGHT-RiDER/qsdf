import React from 'react';

// Loader
import { css } from "@emotion/react";
import HashLoader from "react-spinners/HashLoader";


// Import UseForm 
import { useForm } from 'react-hook-form';

// Mui 
import { Button } from '@mui/material';
import IconButton from '@mui/material/IconButton';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import FormHelperText from '@mui/material/FormHelperText';
import OutlinedInput from '@mui/material/OutlinedInput';

// Mui Icon 
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';

// Firebase 
import { doc, updateDoc, deleteDoc, collection, setDoc, onSnapshot, query } from "firebase/firestore";
import { db, storage } from '../firebase';
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";

// Sweet Alert 
import swal from 'sweetalert';

// React Modal 
import ReactModal from 'react-modal';

const override = css`
  display: block;
  margin: 0 auto;
`;

const ProductTable = ({ cate, data }) => {
    console.log(data)

    const { register, handleSubmit, formState: { errors }, setValue, reset } = useForm();

    const [categories, setCategories] = React.useState([]);
    const [showModal, setShowModal] = React.useState(false);
    const [loading, setLoading] = React.useState(false);
    const [index, setIndex] = React.useState();
    const [ingredient, setIngredient] = React.useState([]);
    const [selectedIngredients, setSelectedIngredients] = React.useState([]);

    let [color] = React.useState("#000");

    const handleOpenModal = (id) => {
        console.log(data[id])
        setValue("pname", data[id].p_name);
        setValue("ingredient", data[id].p_ingredient);
        setValue("price", data[id].p_price);
        setIndex(id);
        setShowModal(true);
    }

    const handleCloseModal = () => {
        setShowModal(false);
        reset();
    }
    const handleChange = (event) => {

        const {
            target: { value },
        } = event;

        let selectedItem = event.target.value[event.target.value.length - 1]
        setSelectedIngredients(old => {
            const uniqueElements = new Set(old);
            if (uniqueElements.has(selectedItem)) {
                uniqueElements.delete(selectedItem);
            } else {
                uniqueElements.add(selectedItem);
            }
            return typeof selectedItem === "string" ? [...uniqueElements] : []
        })

        setIngredient(
            // On autofill we get a stringified value.
            typeof value === 'string' ? value.split(',') : value,
        );


    };
    const deleteProduct = (index, id) => {

        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this file!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
            .then(async (willDelete) => {
                if (willDelete) {
                    setLoading(true);
                    await deleteDoc(doc(db, "products", id))
                        .then(() => {

                            swal("Deleted", "Product Deleted!", "success")
                                .then(() => {
                                    setShowModal(false);
                                });

                        })
                        .catch(err => {
                            setLoading(false);
                            alert(err.message);
                        })
                }
            });
    }

    const onSubmit = async values => {

        setLoading(true);


        if (values.file.length === 0) {

            var id = data[index].p_id;

            const docRef = doc(db, "products", id);

            await updateDoc(docRef, {
                c_id: values.cate,
                p_ingredient: selectedIngredients,
                p_name: values.pname,
                p_price: values.price
            })
                .then(() => {

                    setLoading(false);

                    swal("Updated", "Product Updated!", "success")
                        .then(() => {
                            setShowModal(false);
                            reset();
                        });

                })
                .catch(err => {
                    setLoading(false);
                    alert(err.message);
                })

        }
        else {

            var allowedExtension = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/bmp'];
            var isValidFile = false;
            for (var i in allowedExtension) {

                if (values.file[0].type === allowedExtension[i]) {
                    isValidFile = true;
                    break;
                }
            }


            if (!isValidFile) {
                alert('Allowed Extensions are : *.' + allowedExtension.join(', *.'));
                setLoading(false);
                return
            }

            const storageRef = ref(storage, data[index].p_id);

            uploadBytes(storageRef, values.file[0])
                .then(() => {
                    getDownloadURL(storageRef)
                        .then(async url => {
                            await updateDoc(doc(db, "products", data[index].p_id), {
                                c_id: values.cate,
                                p_image: url,
                                p_ingredient: values.ingredient,
                                p_name: values.pname,
                                p_price: values.price
                            })
                                .then(() => {
                                    setLoading(false);

                                    swal("Updated", "Product Updated!", "success")
                                        .then(() => {
                                            setShowModal(false);
                                            reset();
                                        });
                                })
                                .catch(err => {
                                    setLoading(false);
                                    alert(err.message);
                                })
                        })
                })

        }
    }
    const getIngredients = async () => {
        const q = query(collection(db, "ingredients"));

        onSnapshot(q, (querySnapshot) => {
            setIngredient([]);
            querySnapshot.forEach((doc) => {
                setIngredient((pre) => [...pre, doc.data()]);
            });
        });
    };

    const getCategories = async () => {
        const q = query(collection(db, "categories"));

        onSnapshot(q, (querySnapshot) => {
            setCategories([]);
            querySnapshot.forEach((doc) => {
                setCategories((pre) => [...pre, doc.data()]);
            });
        });

    };

    React.useEffect(() => {
        getIngredients();
        getCategories();
    }, [])
    return (

        <div className="container mt-5">

            <div className={loading ? 'process-loading' : null} >
                <HashLoader
                    color={color}
                    loading={loading}
                    css={override}
                    size={70} />
            </div>

            <div className="table-responsive" >
                <table className="table table-hover table-lg">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Ingredients</th>
                            <th scope="col">Category</th>
                            <th scope="col">Price</th>
                            <th scope="col">Image</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map((v, i) => (
                            <tr key={i}>
                                <th>{i + 1}</th>
                                <td>{v.p_name}</td>
                                <td>{v.p_ingredient.join(' ')}</td>
                                <td>{v.c_id}</td>
                                <td>€{v.p_price}</td>
                                <td>
                                    <img src={v.p_image} width={100} height={100} alt="javed" />
                                </td>
                                <td>
                                    <Button
                                        variant='contained'
                                        className='mx-1'
                                        onClick={() => handleOpenModal(i)}
                                        data-bs-toggle="modal"
                                        data-bs-target="#staticBackdrop">
                                        Edit
                                    </Button>
                                    <Button
                                        variant='contained'
                                        color='error'
                                        onClick={() => deleteProduct(i, v.p_id)} className='mx-1' >
                                        Delete
                                    </Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div >

            <ReactModal
                isOpen={showModal}
                style={{
                    content: {
                        width: "60%",
                        margin: '100px auto 0px auto'

                    }
                }}
                contentLabel="Minimal Modal Example"
            >
                <div className='text-end'>
                    <IconButton aria-label="close" onClick={handleCloseModal}>
                        <CloseRoundedIcon />
                    </IconButton>
                </div>

                <h1 className='text-center h4'>Update Product</h1>

                <div className="row">

                    <div className="col-lg-8 col-md-8 col-sm-10 col-12 mx-auto">

                        <form onSubmit={handleSubmit(onSubmit)} className='mt-5'>

                            <div className='mb-3'>
                                <TextField
                                    label="Product Name"
                                    fullWidth
                                    variant="outlined"
                                    size='small'
                                    {...register("pname", {
                                        required: {
                                            value: true,
                                            message: "Product Name is required"
                                        }
                                    })}
                                    error={errors.pname}
                                />
                                {errors.pname && <FormHelperText error>{errors.pname.message}</FormHelperText>}
                            </div>

                            <div className='mb-3'>
                                <FormControl fullWidth>
                                    <InputLabel id="demo-multiple-name-label">Ingredient</InputLabel>
                                    <Select
                                        labelId="demo-multiple-name-label"
                                        id="demo-multiple-name"
                                        multiple
                                        onChange={handleChange}
                                        onSelect={(e) => console.log(e.target.value, "ON SELECT")}
                                        input={<OutlinedInput label="Product Ingredient" />}
                                        value={ingredient}
                                        error={errors.ingredient}
                                    >
                                        {ingredient.map((v, i) => (
                                            <MenuItem value={v.ingredient_name} key={i}>
                                                {v.ingredient_name}
                                            </MenuItem>
                                        ))}
                                    </Select>
                                    {errors.ingredient && (
                                        <FormHelperText error>{errors.ingredient.message}</FormHelperText>
                                    )}
                                </FormControl>
                            </div>

                            <div className='mb-3'>
                                <TextField
                                    label="Product Price"
                                    fullWidth
                                    variant="outlined"
                                    size='small'
                                    {...register("price", {
                                        required: {
                                            value: true,
                                            message: "Price is required"
                                        }
                                    })}
                                    error={errors.price}
                                />
                                {errors.price && <FormHelperText error>{errors.price.message}</FormHelperText>}
                            </div>

                            <div className='mb-3'>
                                <input
                                    type="file"
                                    className='form-control'
                                    {...register('file')}
                                />
                            </div>

                            <div className="mb-3">
                                <FormControl fullWidth>
                                    <InputLabel id="demo-simple-select-label">
                                        Category
                  </InputLabel>
                                    <Select
                                        labelId="demo-simple-select-label"
                                        id="demo-simple-select"
                                        label="Category"
                                        {...register("cate", {
                                            required: {
                                                value: true,
                                                message: "Select Category",
                                            },
                                        })}
                                        error={errors.cate}
                                    >
                                        {categories.map((v, i) => (
                                            <MenuItem value={v.cat_name} key={i}>
                                                {v.cat_name}
                                            </MenuItem>
                                        ))}
                                    </Select>
                                    {errors.cate && (
                                        <FormHelperText error>{errors.cate.message}</FormHelperText>
                                    )}
                                </FormControl>
                            </div>
                            <Button
                                type="submit"
                                variant='contained'
                                fullWidth
                                size='large'>Update</Button>

                        </form>

                    </div>

                </div>

            </ReactModal>

        </div>

    )
}

export default ProductTable
