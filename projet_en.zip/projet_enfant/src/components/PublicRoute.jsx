import React from 'react'
import { Navigate, Outlet } from 'react-router-dom'

const PublicRoute = ({ isLogin }) => {

    return (
        <React.Fragment>
            {!isLogin ? <Outlet /> : <Navigate to='/' />}
        </React.Fragment>
    )
}

export default PublicRoute;
