import React from 'react'
import { Navigate, Outlet } from 'react-router-dom';

const PrivateRoute = ({ isLogin }) => {

    return (
        <React.Fragment>
            {isLogin ? <Outlet /> : <Navigate to='/login' />}
        </React.Fragment>
    )
}

export default PrivateRoute;
