import React from 'react';

// Loader
import { css } from "@emotion/react";
import HashLoader from "react-spinners/HashLoader";

// Router 
import { Routes, Route } from 'react-router-dom';

// Public and Private Routes 
import PrivateRoute from './components/PrivateRoute';
import PublicRoute from './components/PublicRoute';

// Pages 
import Login from './pages/Login';
import Products from './pages/Products';
import Order from './pages/Order';
import Category from './pages/Category';
import OrderAccept from './pages/OrderAccept';
import Dashboard from './pages/Dashboard';
import Ingredients from './pages/Ingredients';



// Firebase 
import { onAuthStateChanged } from 'firebase/auth'
import { auth } from './firebase';

// Css 
import './App.css';
import AddUsers from './pages/AddUsers';
import Footer from './components/Footer';
import Charts from './pages/Charts';

const override = css`
  display: block;
  margin: 0 auto;
`;

function App() {

  const [isLogin, setIsLogin] = React.useState();
  const [loading, setLoading] = React.useState(true);
  let [color] = React.useState("#000");

  React.useEffect(() => {
    // const user =localStorage.getItem("checkout_user");

    onAuthStateChanged(auth, user => {
      if (user) {
        setIsLogin(true);
        setLoading(false);
      }
      else {
        setIsLogin(false);
        setLoading(false);
      }
    })
  }, [])


  return (
    <React.Fragment>

      <div className={loading ? 'refresh-loading' : null} >
        <HashLoader
          color={color}
          loading={loading}
          css={override}
          size={70} />
      </div>


      <Routes>


        {/* Private Routes  */}
        {/* <Route exact path='/' element={<PrivateRoute isLogin={isLogin} />}>
          <Route exact path='/' element={<Dashboard />} />
        </Route> */}

        <Route exact path='/products' >
          <Route exact path='/products' element={<Products />} />
        </Route>
{/* 
        <Route exact path='/users' element={<PrivateRoute isLogin={isLogin} />}>
          <Route exact path='/users' element={<AddUsers />} />
        </Route>

        <Route exact path='/orders' element={<PrivateRoute isLogin={isLogin} />}>
          <Route exact path='/orders' element={<Order />} />
        </Route>

        <Route exact path='/category' element={<PrivateRoute isLogin={isLogin} />}>
          <Route exact path='/category' element={<Category />} />
        </Route>

        <Route exact path='/ingredients' element={<PrivateRoute isLogin={isLogin} />}>
          <Route exact path='/ingredients' element={<Ingredients />} />
        </Route>

        <Route exact path='/order-accept' element={<PrivateRoute isLogin={isLogin} />}>
          <Route exact path='/order-accept' element={<OrderAccept />} />
        </Route>

        <Route exact path='/charts' element={<PrivateRoute isLogin={isLogin} />}>
          <Route exact path='/charts' element={<Charts />} />
        </Route>

        {/* Public Routes  */}
        {/* <Route exact path='/login' element={<PublicRoute isLogin={isLogin} />}>
          <Route exact path='/login' element={<Login />} />
        </Route> */} */}

      </Routes>
      <Footer/>
    </React.Fragment >
  );
}

export default App;
